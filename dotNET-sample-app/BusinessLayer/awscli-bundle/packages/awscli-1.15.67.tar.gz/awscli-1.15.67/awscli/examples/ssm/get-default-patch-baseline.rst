**To display the default patch baseline**

This example displays the default patch baseline.

Command::

  aws ssm get-default-patch-baseline

Output::

  {
    "BaselineId":"arn:aws:ssm:us-west-1:812345678901:patchbaseline/pb-0ca44a362f8afc725"
  }
